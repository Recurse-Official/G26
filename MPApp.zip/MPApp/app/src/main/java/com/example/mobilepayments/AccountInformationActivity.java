package com.example.mobilepayments;

public class AccountInformationActivity {

}
